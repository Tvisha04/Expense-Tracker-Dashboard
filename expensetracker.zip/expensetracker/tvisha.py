import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import sqlite3
from datetime import datetime
import calendar
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd
import numpy as np
from tkcalendar import DateEntry
import os
from PIL import Image, ImageTk
import csv

class ExpenseTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Expense Tracker")
        self.root.geometry("1100x700")
        self.root.configure(bg="#f5f5f5")
        
        # Set style
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TFrame", background="#f5f5f5")
        self.style.configure("TLabel", background="#f5f5f5", font=("Arial", 10))
        self.style.configure("TButton", font=("Arial", 10, "bold"))
        self.style.configure("Treeview", font=("Arial", 9))
        self.style.configure("Treeview.Heading", font=("Arial", 10, "bold"))
        
        # Initialize database
        self.conn = self.initialize_database()
        
        # Categories
        self.categories = [
            "Food & Dining", "Shopping", "Housing", "Transportation", 
            "Entertainment", "Health & Wellness", "Education", "Utilities",
            "Investments", "Gifts & Donations", "Personal Care", "Travel",
            "Others"
        ]
        
        # Track selected expense for editing
        self.selected_expense_id = None
        
        # Initialize current month and year
        self.current_month = datetime.now().month
        self.current_year = datetime.now().year
        
        # Create UI components
        self.create_header()
        self.create_main_content()
        self.create_sidebar()
        
        # Load initial data
        self.refresh_expense_list()
        self.update_dashboard()
        
    def initialize_database(self):
        """Initialize SQLite database"""
        if not os.path.exists('./data'):
            os.makedirs('./data')
            
        conn = sqlite3.connect('./data/expense_tracker.db')
        cursor = conn.cursor()
        
        # Create expenses table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            payment_method TEXT,
            year INTEGER,
            month INTEGER
        )
        ''')
        
        # Create budget table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS budget (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT UNIQUE,
            amount REAL
        )
        ''')
        
        conn.commit()
        return conn
    
    def create_header(self):
        """Create the header section"""
        header_frame = ttk.Frame(self.root)
        header_frame.pack(fill=tk.X, padx=20, pady=10)
        
        title_label = ttk.Label(
            header_frame, 
            text="Smart Expense Tracker", 
            font=("Arial", 18, "bold"), 
            foreground="#333333"
        )
        title_label.pack(side=tk.LEFT)
        
        # Month and Year selector
        selector_frame = ttk.Frame(header_frame)
        selector_frame.pack(side=tk.RIGHT)
        
        # Previous month button
        prev_btn = ttk.Button(
            selector_frame, 
            text="◀", 
            command=self.previous_month,
            width=3
        )
        prev_btn.pack(side=tk.LEFT, padx=5)
        
        # Month label
        self.month_year_label = ttk.Label(
            selector_frame, 
            text=f"{calendar.month_name[self.current_month]} {self.current_year}", 
            font=("Arial", 12, "bold"),
            foreground="#333333"
        )
        self.month_year_label.pack(side=tk.LEFT, padx=10)
        
        # Next month button
        next_btn = ttk.Button(
            selector_frame, 
            text="▶", 
            command=self.next_month,
            width=3
        )
        next_btn.pack(side=tk.LEFT, padx=5)
    
    def create_main_content(self):
        """Create the main content area"""
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Left side for dashboard
        dashboard_frame = ttk.Frame(main_frame)
        dashboard_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Summary cards frame
        summary_frame = ttk.Frame(dashboard_frame)
        summary_frame.pack(fill=tk.X, pady=10)
        
        # Create summary cards
        self.create_summary_card(summary_frame, "Total Expenses", "0.00", "#e74c3c")
        self.create_summary_card(summary_frame, "Budget", "0.00", "#2ecc71") 
        self.create_summary_card(summary_frame, "Remaining", "0.00", "#3498db")
        
        # Chart selection dropdown
        chart_control_frame = ttk.Frame(dashboard_frame)
        chart_control_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(chart_control_frame, text="Chart Type:").pack(side=tk.LEFT, padx=(0, 5))
        self.chart_type_var = tk.StringVar(value="Categories")
        chart_types = ["Categories", "Daily Expenses", "Expense Trend", "Spending Pattern", "Expense vs Date"]
        chart_dropdown = ttk.Combobox(chart_control_frame, textvariable=self.chart_type_var, 
                                     values=chart_types, state="readonly", width=15)
        chart_dropdown.pack(side=tk.LEFT)
        chart_dropdown.bind("<<ComboboxSelected>>", self.update_selected_chart)
        
        # Refresh button
        refresh_btn = ttk.Button(chart_control_frame, text="Refresh", command=self.update_dashboard)
        refresh_btn.pack(side=tk.RIGHT)
        
        # Chart frames
        self.charts_frame = ttk.Frame(dashboard_frame)
        self.charts_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Main chart frame (will be filled based on selection)
        self.main_chart_frame = ttk.LabelFrame(self.charts_frame, text="Expense Analysis")
        self.main_chart_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Chart content frame
        self.chart_content_frame = ttk.Frame(self.main_chart_frame)
        self.chart_content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Payment mode distribution frame
        payment_frame = ttk.LabelFrame(self.charts_frame, text="Payment Mode Distribution")
        payment_frame.pack(fill=tk.X, padx=5, pady=5)
        self.payment_chart_frame = ttk.Frame(payment_frame)
        self.payment_chart_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Configure grid weights
        self.charts_frame.grid_columnconfigure(0, weight=1)
        self.charts_frame.grid_rowconfigure(0, weight=4)
        self.charts_frame.grid_rowconfigure(1, weight=1)
    
    def create_summary_card(self, parent, title, value, color):
        """Create a summary card with specified title and value"""
        card = ttk.Frame(parent, borderwidth=2, relief="ridge")
        card.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)
        
        title_label = ttk.Label(
            card, 
            text=title, 
            font=("Arial", 10), 
            foreground="#555555"
        )
        title_label.pack(anchor="w", padx=10, pady=(10, 5))
        
        # Colored frame for the value
        value_frame = ttk.Frame(card)
        value_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        if title == "Total Expenses":
            self.total_expenses_label = ttk.Label(
                value_frame, 
                text=f"₹{value}", 
                font=("Arial", 14, "bold"), 
                foreground=color
            )
            self.total_expenses_label.pack(anchor="w")
        elif title == "Budget":
            self.budget_label = ttk.Label(
                value_frame, 
                text=f"₹{value}", 
                font=("Arial", 14, "bold"), 
                foreground=color
            )
            self.budget_label.pack(anchor="w")
        else:  # Remaining
            self.remaining_label = ttk.Label(
                value_frame, 
                text=f"₹{value}", 
                font=("Arial", 14, "bold"), 
                foreground=color
            )
            self.remaining_label.pack(anchor="w")
    
    def create_sidebar(self):
        """Create the sidebar for adding expenses and showing the expense list"""
        sidebar_frame = ttk.Frame(self.root, width=300, borderwidth=2, relief="ridge")
        sidebar_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 20), pady=10)
        
        # Add Expense section
        add_expense_frame = ttk.LabelFrame(sidebar_frame, text="Add New Expense")
        add_expense_frame.pack(fill=tk.X, padx=10, pady=10, ipady=5)
        
        # Date field
        ttk.Label(add_expense_frame, text="Date:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.date_entry = DateEntry(add_expense_frame, width=15, background='darkblue',
                               foreground='white', borderwidth=2, date_pattern='yyyy-mm-dd')
        self.date_entry.grid(row=0, column=1, sticky="w", padx=5, pady=5)
        
        # Amount field
        ttk.Label(add_expense_frame, text="Amount:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.amount_var = tk.StringVar()
        self.amount_entry = ttk.Entry(add_expense_frame, textvariable=self.amount_var, width=18)
        self.amount_entry.grid(row=1, column=1, sticky="w", padx=5, pady=5)
        
        # Category field
        ttk.Label(add_expense_frame, text="Category:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.category_var = tk.StringVar()
        self.category_combo = ttk.Combobox(add_expense_frame, textvariable=self.category_var, width=15)
        self.category_combo['values'] = self.categories
        self.category_combo.grid(row=2, column=1, sticky="w", padx=5, pady=5)
        
        # Description field
        ttk.Label(add_expense_frame, text="Description:").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.description_var = tk.StringVar()
        self.description_entry = ttk.Entry(add_expense_frame, textvariable=self.description_var, width=18)
        self.description_entry.grid(row=3, column=1, sticky="w", padx=5, pady=5)
        
        # Payment method field
        ttk.Label(add_expense_frame, text="Payment Method:").grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.payment_var = tk.StringVar()
        self.payment_combo = ttk.Combobox(add_expense_frame, textvariable=self.payment_var, width=15)
        self.payment_combo['values'] = ["Cash", "Credit Card", "Debit Card", "UPI", "Bank Transfer", "Other"]
        self.payment_combo.grid(row=4, column=1, sticky="w", padx=5, pady=5)
        
        # Add and Update buttons
        button_frame = ttk.Frame(add_expense_frame)
        button_frame.grid(row=5, column=0, columnspan=2, pady=10)
        
        self.add_button = ttk.Button(button_frame, text="Add Expense", command=self.add_expense)
        self.add_button.pack(side=tk.LEFT, padx=5)
        
        self.update_button = ttk.Button(button_frame, text="Update", command=self.update_expense, state="disabled")
        self.update_button.pack(side=tk.LEFT, padx=5)
        
        self.clear_button = ttk.Button(button_frame, text="Clear", command=self.clear_form)
        self.clear_button.pack(side=tk.LEFT, padx=5)
        
        # Budget Settings button
        budget_button = ttk.Button(sidebar_frame, text="Budget Settings", command=self.open_budget_settings)
        budget_button.pack(pady=5, padx=10, fill=tk.X)
        
        # Export button
        export_button = ttk.Button(sidebar_frame, text="Export Data", command=self.export_data)
        export_button.pack(pady=5, padx=10, fill=tk.X)
        
        # Expenses List section
        expenses_frame = ttk.LabelFrame(sidebar_frame, text="Expenses List")
        expenses_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create treeview for expenses list
        self.expenses_tree = ttk.Treeview(expenses_frame, columns=("Date", "Amount", "Category", "Description"))
        self.expenses_tree.heading("#0", text="ID")
        self.expenses_tree.heading("Date", text="Date")
        self.expenses_tree.heading("Amount", text="Amount")
        self.expenses_tree.heading("Category", text="Category")
        self.expenses_tree.heading("Description", text="Description")
        
        self.expenses_tree.column("#0", width=0, stretch=tk.NO)
        self.expenses_tree.column("Date", width=70)
        self.expenses_tree.column("Amount", width=70)
        self.expenses_tree.column("Category", width=100)
        self.expenses_tree.column("Description", width=120)
        
        self.expenses_tree.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(expenses_frame, orient="vertical", command=self.expenses_tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.expenses_tree.configure(yscrollcommand=scrollbar.set)
        
        # Bind select event
        self.expenses_tree.bind("<<TreeviewSelect>>", self.on_expense_select)
        
        # Add right-click menu
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Edit", command=self.edit_selected_expense)
        self.context_menu.add_command(label="Delete", command=self.delete_selected_expense)
        self.expenses_tree.bind("<Button-3>", self.show_context_menu)
    
    def add_expense(self):
        """Add a new expense to the database"""
        try:
            date = self.date_entry.get_date().strftime("%Y-%m-%d")
            amount = float(self.amount_var.get())
            category = self.category_var.get()
            description = self.description_var.get()
            payment_method = self.payment_var.get()
            
            # Validate inputs
            if amount <= 0:
                messagebox.showerror("Error", "Amount must be greater than zero.")
                return
                
            if not category:
                messagebox.showerror("Error", "Please select a category.")
                return
            
            # Extract year and month from date
            date_obj = datetime.strptime(date, "%Y-%m-%d")
            year = date_obj.year
            month = date_obj.month
            
            cursor = self.conn.cursor()
            cursor.execute(
                '''INSERT INTO expenses (date, amount, category, description, payment_method, year, month) 
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (date, amount, category, description, payment_method, year, month)
            )
            self.conn.commit()
            
            # Clear the form after adding
            self.clear_form()
            
            # Refresh the expenses list
            self.refresh_expense_list()
            
            # Update dashboard
            self.update_dashboard()
            
            messagebox.showinfo("Success", "Expense added successfully!")
            
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid amount.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def update_expense(self):
        """Update an existing expense"""
        if not self.selected_expense_id:
            return
            
        try:
            date = self.date_entry.get_date().strftime("%Y-%m-%d")
            amount = float(self.amount_var.get())
            category = self.category_var.get()
            description = self.description_var.get()
            payment_method = self.payment_var.get()
            
            # Validate inputs
            if amount <= 0:
                messagebox.showerror("Error", "Amount must be greater than zero.")
                return
                
            if not category:
                messagebox.showerror("Error", "Please select a category.")
                return
            
            # Extract year and month from date
            date_obj = datetime.strptime(date, "%Y-%m-%d")
            year = date_obj.year
            month = date_obj.month
            
            cursor = self.conn.cursor()
            cursor.execute(
                '''UPDATE expenses 
                SET date=?, amount=?, category=?, description=?, payment_method=?, year=?, month=? 
                WHERE id=?''',
                (date, amount, category, description, payment_method, year, month, self.selected_expense_id)
            )
            self.conn.commit()
            
            # Clear the form and reset buttons
            self.clear_form()
            
            # Refresh the expenses list
            self.refresh_expense_list()
            
            # Update dashboard
            self.update_dashboard()
            
            messagebox.showinfo("Success", "Expense updated successfully!")
            
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid amount.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def clear_form(self):
        """Clear the form fields and reset buttons"""
        self.date_entry.set_date(datetime.now())
        self.amount_var.set("")
        self.category_var.set("")
        self.description_var.set("")
        self.payment_var.set("")
        self.selected_expense_id = None
        self.update_button.config(state="disabled")
        self.add_button.config(state="normal")
    
    def on_expense_select(self, event):
        """Handle expense selection in the treeview"""
        selected_items = self.expenses_tree.selection()
        if not selected_items:
            return
            
        # Get the expense ID (stored in the treeview item ID)
        item_id = selected_items[0]
        self.selected_expense_id = self.expenses_tree.item(item_id, "values")[0]
        
        # Fetch the expense details
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM expenses WHERE id=?", (self.selected_expense_id,))
        expense = cursor.fetchone()
        
        if not expense:
            return
            
        # Populate the form with expense details
        self.date_entry.set_date(datetime.strptime(expense[1], "%Y-%m-%d"))
        self.amount_var.set(str(expense[2]))
        self.category_var.set(expense[3])
        self.description_var.set(expense[4] if expense[4] else "")
        self.payment_var.set(expense[5] if expense[5] else "")
        
        # Update button states
        self.update_button.config(state="normal")
        self.add_button.config(state="disabled")
    
    def edit_selected_expense(self):
        """Edit the selected expense"""
        selected_items = self.expenses_tree.selection()
        if not selected_items:
            return
            
        self.on_expense_select(None)  # Use the same logic as selecting
    
    def delete_selected_expense(self):
        """Delete the selected expense"""
        selected_items = self.expenses_tree.selection()
        if not selected_items:
            return
            
        item_id = selected_items[0]
        expense_id = self.expenses_tree.item(item_id, "values")[0]
        
        # Confirm deletion
        if not messagebox.askyesno("Confirm", "Are you sure you want to delete this expense?"):
            return
            
        try:
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM expenses WHERE id=?", (expense_id,))
            self.conn.commit()
            
            # Refresh the expenses list
            self.refresh_expense_list()
            
            # Update dashboard
            self.update_dashboard()
            
            # Clear form if the deleted expense was selected
            if self.selected_expense_id == expense_id:
                self.clear_form()
                
            messagebox.showinfo("Success", "Expense deleted successfully!")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def show_context_menu(self, event):
        """Show context menu on right-click"""
        if self.expenses_tree.selection():
            self.context_menu.post(event.x_root, event.y_root)
    
    def refresh_expense_list(self):
        """Refresh the expenses list for the current month and year"""
        # Clear current items
        for item in self.expenses_tree.get_children():
            self.expenses_tree.delete(item)
            
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT id, date, amount, category, description FROM expenses WHERE month=? AND year=? ORDER BY date DESC",
                (self.current_month, self.current_year)
            )
            expenses = cursor.fetchall()
            
            for expense in expenses:
                # Format the date
                date_obj = datetime.strptime(expense[1], "%Y-%m-%d")
                formatted_date = date_obj.strftime("%d-%b")
                
                # Format the amount
                formatted_amount = f"₹{expense[2]:.2f}"
                
                # Insert into treeview
                self.expenses_tree.insert("", "end", values=(expense[0], formatted_date, formatted_amount, expense[3], expense[4]))
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while refreshing expenses: {str(e)}")
    
    def update_dashboard(self):
        """Update the dashboard with current data"""
        try:
            cursor = self.conn.cursor()
            
            # Get total expenses for current month
            cursor.execute(
                "SELECT SUM(amount) FROM expenses WHERE month=? AND year=?",
                (self.current_month, self.current_year)
            )
            total_expenses = cursor.fetchone()[0] or 0
            
            # Get budget for current month
            cursor.execute("SELECT SUM(amount) FROM budget")
            total_budget = cursor.fetchone()[0] or 0
            
            # Calculate remaining budget
            remaining = total_budget - total_expenses
            
            # Update summary labels
            self.total_expenses_label.config(text=f"₹{total_expenses:.2f}")
            self.budget_label.config(text=f"₹{total_budget:.2f}")
            self.remaining_label.config(text=f"₹{remaining:.2f}")
            
            # Update the selected chart
            self.update_selected_chart()
            
            # Update payment mode chart
            self.update_payment_mode_chart()
            
            # Update month/year label
            self.month_year_label.config(text=f"{calendar.month_name[self.current_month]} {self.current_year}")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating dashboard: {str(e)}")
    
    def update_selected_chart(self, event=None):
        """Update the chart based on selection"""
        chart_type = self.chart_type_var.get()
        
        # Clear previous chart
        for widget in self.chart_content_frame.winfo_children():
            widget.destroy()
            
        if chart_type == "Categories":
            self.main_chart_frame.config(text="Expenses by Category")
            self.update_category_chart()
        elif chart_type == "Daily Expenses":
            self.main_chart_frame.config(text="Daily Expenses")
            self.update_daily_chart()
        elif chart_type == "Expense Trend":
            self.main_chart_frame.config(text="Expense Trend (Last 6 Months)")
            self.update_trend_chart()
        elif chart_type == "Spending Pattern":
            self.main_chart_frame.config(text="Spending Pattern Analysis")
            self.update_spending_pattern_chart()
        elif chart_type == "Expense vs Date":
            self.main_chart_frame.config(text="Expense Amount vs Date")
            self.update_expense_scatter_chart()
    
    def update_category_chart(self):
        """Update the category pie chart"""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT category, SUM(amount) FROM expenses WHERE month=? AND year=? GROUP BY category",
                (self.current_month, self.current_year)
            )
            data = cursor.fetchall()
            
            if not data:
                # No data to display
                no_data_label = ttk.Label(self.chart_content_frame, text="No data available for this month")
                no_data_label.pack(expand=True)
                return
                
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 5), dpi=100)
            
            categories = [item[0] for item in data]
            amounts = [item[1] for item in data]
            
            # Use a color palette
            colors = plt.cm.Pastel1(range(len(categories)))
            
            # Plot pie chart
            wedges, texts, autotexts = ax.pie(
                amounts, 
                labels=None, 
                autopct='%1.1f%%', 
                startangle=90, 
                colors=colors,
                textprops={'fontsize': 9}
            )
            
            # Equal aspect ratio ensures pie is drawn as a circle
            ax.axis('equal')
            
            # Create legend
            ax.legend(
                wedges, 
                categories, 
                title="Categories", 
                loc="center left", 
                bbox_to_anchor=(0.9, 0, 0.5, 1),
                fontsize=9
            )
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.chart_content_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating category chart: {str(e)}")
    
    def update_daily_chart(self):
        """Update the daily expenses bar chart"""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT date, SUM(amount) FROM expenses WHERE month=? AND year=? GROUP BY date ORDER BY date",
                (self.current_month, self.current_year)
            )
            data = cursor.fetchall()
            
            if not data:
                # No data to display
                no_data_label = ttk.Label(self.chart_content_frame, text="No data available for this month")
                no_data_label.pack(expand=True)
                return
                
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 5), dpi=100)
            
            dates = [datetime.strptime(item[0], "%Y-%m-%d").day for item in data]
            amounts = [item[1] for item in data]
            
            # Plot bar chart
            bars = ax.bar(dates, amounts, color='#3498db', alpha=0.7)
            
            # Add amount labels on top of each bar
            for bar, amount in zip(bars, amounts):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                        f'₹{amount:.0f}', ha='center', va='bottom', fontsize=8, rotation=45)
            
            # Add labels and formatting
            ax.set_xlabel('Day of Month', fontsize=10)
            ax.set_ylabel('Amount (₹)', fontsize=10)
            ax.set_title(f'Daily Expenses - {calendar.month_name[self.current_month]} {self.current_year}', fontsize=12)
            ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.chart_content_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating daily chart: {str(e)}")
    
    def update_trend_chart(self):
        """Update the expense trend line chart"""
        try:
            # Calculate the date range for the last 6 months
            end_month = self.current_month
            end_year = self.current_year
            
            months = []
            years = []
            
            for i in range(6):
                months.append(end_month)
                years.append(end_year)
                
                end_month -= 1
                if end_month == 0:
                    end_month = 12
                    end_year -= 1
            
            # Reverse to get chronological order
            months.reverse()
            years.reverse()
            
            cursor = self.conn.cursor()
            monthly_totals = []
            month_labels = []
            
            for i in range(6):
                cursor.execute(
                    "SELECT SUM(amount) FROM expenses WHERE month=? AND year=?",
                    (months[i], years[i])
                )
                total = cursor.fetchone()[0] or 0
                monthly_totals.append(total)
                
                # Create month label (e.g., "Jan '23")
                month_name = calendar.month_abbr[months[i]]
                year_short = str(years[i])[-2:]
                month_labels.append(f"{month_name} '{year_short}")
            
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 5), dpi=100)
            
            # Plot line chart with markers
            ax.plot(month_labels, monthly_totals, marker='o', linestyle='-', color='#2980b9', linewidth=2, markersize=8)
            
            # Add data point labels
            for i, (x, y) in enumerate(zip(month_labels, monthly_totals)):
                ax.annotate(f'₹{y:.0f}', (x, y), textcoords="offset points", 
                            xytext=(0, 10), ha='center', fontsize=9)
            
            # Add grid lines
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # Add labels and formatting
            ax.set_xlabel('Month', fontsize=10)
            ax.set_ylabel('Total Expenses (₹)', fontsize=10)
            ax.set_title('Expense Trend - Last 6 Months', fontsize=12)
            
            # Rotate x-axis labels for better readability
            plt.xticks(rotation=45)
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.chart_content_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating trend chart: {str(e)}")
            
    def update_spending_pattern_chart(self):
        """Update the spending pattern histogram"""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT amount FROM expenses WHERE month=? AND year=?",
                (self.current_month, self.current_year)
            )
            data = cursor.fetchall()
            
            if not data:
                # No data to display
                no_data_label = ttk.Label(self.chart_content_frame, text="No data available for this month")
                no_data_label.pack(expand=True)
                return
            
            # Extract amounts
            amounts = [item[0] for item in data]
            
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 5), dpi=100)
            
            # Determine number of bins based on data
            n_bins = min(max(5, len(amounts) // 2), 15)  # Between 5 and 15 bins
            
            # Plot histogram
            n, bins, patches = ax.hist(amounts, bins=n_bins, color='#9b59b6', alpha=0.7, edgecolor='black')
            
            # Add a kde line
            if len(amounts) > 3:  # Need at least a few points for kde
                try:
                    from scipy import stats
                    kde_x = np.linspace(min(amounts), max(amounts), 100)
                    kde = stats.gaussian_kde(amounts)
                    ax.plot(kde_x, kde(kde_x) * len(amounts) * (bins[1] - bins[0]), 
                            color='#e74c3c', linewidth=2)
                except ImportError:
                    pass  # scipy not available
            
            # Add labels and formatting
            ax.set_xlabel('Expense Amount (₹)', fontsize=10)
            ax.set_ylabel('Frequency', fontsize=10)
            ax.set_title(f'Spending Pattern Distribution - {calendar.month_name[self.current_month]} {self.current_year}', fontsize=12)
            ax.grid(True, alpha=0.3)
            
            # Add stats
            if amounts:
                stats_text = (f"Average: ₹{np.mean(amounts):.2f}\n"
                            f"Median: ₹{np.median(amounts):.2f}\n"
                            f"Max: ₹{max(amounts):.2f}\n"
                            f"Min: ₹{min(amounts):.2f}")
                ax.text(0.95, 0.95, stats_text, transform=ax.transAxes, fontsize=9,
                        verticalalignment='top', horizontalalignment='right',
                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.chart_content_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating spending pattern chart: {str(e)}")
    
    def update_expense_scatter_chart(self):
        """Update the expense vs date scatter plot"""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT date, amount, category FROM expenses WHERE month=? AND year=?",
                (self.current_month, self.current_year)
            )
            data = cursor.fetchall()
            
            if not data:
                # No data to display
                no_data_label = ttk.Label(self.chart_content_frame, text="No data available for this month")
                no_data_label.pack(expand=True)
                return
            
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 5), dpi=100)
            
            # Extract data
            dates = [datetime.strptime(item[0], "%Y-%m-%d").day for item in data]
            amounts = [item[1] for item in data]
            categories = [item[2] for item in data]
            
            # Get unique categories for color mapping
            unique_categories = list(set(categories))
            colors = plt.cm.tab10(np.linspace(0, 1, len(unique_categories)))
            color_map = {cat: color for cat, color in zip(unique_categories, colors)}
            
            # Plot scatter with different colors per category
            for cat in unique_categories:
                cat_dates = [dates[i] for i in range(len(dates)) if categories[i] == cat]
                cat_amounts = [amounts[i] for i in range(len(amounts)) if categories[i] == cat]
                ax.scatter(cat_dates, cat_amounts, label=cat, color=color_map[cat], 
                        alpha=0.7, s=70, edgecolors='black')
            
            # Add best fit line if enough points
            if len(dates) > 2:
                try:
                    z = np.polyfit(dates, amounts, 1)
                    p = np.poly1d(z)
                    x_line = np.linspace(min(dates), max(dates), 100)
                    ax.plot(x_line, p(x_line), linestyle='--', color='black', alpha=0.7)
                    
                    # Calculate correlation
                    if len(dates) > 2:  # Need at least 3 points for correlation
                        from scipy import stats
                        corr, p_value = stats.pearsonr(dates, amounts)
                        trend_text = f"Trend: {'Increasing' if z[0] > 0 else 'Decreasing'}\nCorrelation: {corr:.2f}"
                        ax.text(0.05, 0.95, trend_text, transform=ax.transAxes, fontsize=9,
                                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
                except:
                    pass  # Skip if there's an error with the fit
            
            # Add labels and formatting
            ax.set_xlabel('Day of Month', fontsize=10)
            ax.set_ylabel('Expense Amount (₹)', fontsize=10)
            ax.set_title(f'Expense Pattern - {calendar.month_name[self.current_month]} {self.current_year}', fontsize=12)
            ax.grid(True, alpha=0.3)
            
            # Add legend
            if len(unique_categories) <= 10:  # Only show legend if not too many categories
                ax.legend(title="Categories", loc='upper left', bbox_to_anchor=(1, 1))
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.chart_content_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating expense scatter chart: {str(e)}")
    
    def update_payment_mode_chart(self):
        """Update the payment mode distribution chart"""
        try:
            # Clear previous chart
            for widget in self.payment_chart_frame.winfo_children():
                widget.destroy()
                
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT payment_method, COUNT(*) FROM expenses WHERE month=? AND year=? GROUP BY payment_method",
                (self.current_month, self.current_year)
            )
            data = cursor.fetchall()
            
            if not data:
                # No data to display
                no_data_label = ttk.Label(self.payment_chart_frame, text="No data available for this month")
                no_data_label.pack(expand=True)
                return
                
            # Create figure and plot
            fig, ax = plt.subplots(figsize=(8, 2), dpi=100)
            
            # Extract data
            methods = [item[0] if item[0] else "Not Specified" for item in data]
            counts = [item[1] for item in data]
            
            # Plot horizontal bar chart
            y_pos = range(len(methods))
            ax.barh(y_pos, counts, color='#2ecc71', alpha=0.7)
            
            # Add labels inside bars
            for i, count in enumerate(counts):
                ax.text(count / 2, i, str(count), va='center', ha='center', color='black', fontweight='bold')
            
            # Add labels and formatting
            ax.set_yticks(y_pos)
            ax.set_yticklabels(methods)
            ax.set_xlabel('Number of Transactions', fontsize=9)
            ax.set_title('Payment Method Usage', fontsize=10)
            
            plt.tight_layout()
            
            # Embed in Tkinter
            canvas = FigureCanvasTkAgg(fig, master=self.payment_chart_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating payment mode chart: {str(e)}")
    
    def next_month(self):
        """Navigate to the next month"""
        self.current_month += 1
        if self.current_month > 12:
            self.current_month = 1
            self.current_year += 1
        
        self.refresh_expense_list()
        self.update_dashboard()
    
    def previous_month(self):
        """Navigate to the previous month"""
        self.current_month -= 1
        if self.current_month < 1:
            self.current_month = 12
            self.current_year -= 1
        
        self.refresh_expense_list()
        self.update_dashboard()
    
    def open_budget_settings(self):
        """Open budget settings dialog"""
        budget_window = tk.Toplevel(self.root)
        budget_window.title("Budget Settings")
        budget_window.geometry("400x500")
        budget_window.resizable(False, False)
        
        # Create a frame for the budget list
        frame = ttk.Frame(budget_window)
        frame.pack(padx=20, pady=20, fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(frame, text="Monthly Budget Allocation", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 20))
        
        # Create treeview for budget list
        budget_tree = ttk.Treeview(frame, columns=("Category", "Amount"), show="headings")
        budget_tree.heading("Category", text="Category")
        budget_tree.heading("Amount", text="Amount (₹)")
        budget_tree.column("Category", width=200)
        budget_tree.column("Amount", width=150)
        budget_tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=budget_tree.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        budget_tree.configure(yscrollcommand=scrollbar.set)
        
        # Load current budget data
        def load_budget_data():
            # Clear current items
            for item in budget_tree.get_children():
                budget_tree.delete(item)
                
            cursor = self.conn.cursor()
            
            # First add categories with budgets
            cursor.execute("SELECT category, amount FROM budget ORDER BY category")
            budgets = cursor.fetchall()
            
            for budget in budgets:
                budget_tree.insert("", "end", values=(budget[0], f"{budget[1]:.2f}"))
            
            # Then add categories without budgets
            for category in self.categories:
                if category not in [b[0] for b in budgets]:
                    budget_tree.insert("", "end", values=(category, "0.00"))
        
        load_budget_data()
        
        # Add Entry fields for setting a new budget
        input_frame = ttk.Frame(frame)
        input_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(input_frame, text="Category:").grid(row=0, column=0, padx=5, pady=5)
        category_var = tk.StringVar()
        category_combo = ttk.Combobox(input_frame, textvariable=category_var, width=15)
        category_combo['values'] = self.categories
        category_combo.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(input_frame, text="Amount (₹):").grid(row=0, column=2, padx=5, pady=5)
        amount_var = tk.StringVar()
        amount_entry = ttk.Entry(input_frame, textvariable=amount_var, width=10)
        amount_entry.grid(row=0, column=3, padx=5, pady=5)
        
        # Selection handler
        def on_budget_select(event):
            selected_items = budget_tree.selection()
            if not selected_items:
                return
                
            # Get the selected category and amount
            values = budget_tree.item(selected_items[0], "values")
            category_var.set(values[0])
            amount_var.set(values[1].replace("₹", ""))
        
        budget_tree.bind("<<TreeviewSelect>>", on_budget_select)
        
        # Button functions
        def save_budget():
            category = category_var.get()
            
            try:
                amount = float(amount_var.get())
                
                if amount < 0:
                    messagebox.showerror("Error", "Amount must be non-negative.")
                    return
                    
                if not category:
                    messagebox.showerror("Error", "Please select a category.")
                    return
                
                cursor = self.conn.cursor()
                
                # Check if category already has a budget
                cursor.execute("SELECT COUNT(*) FROM budget WHERE category=?", (category,))
                exists = cursor.fetchone()[0] > 0
                
                if exists:
                    cursor.execute("UPDATE budget SET amount=? WHERE category=?", (amount, category))
                else:
                    cursor.execute("INSERT INTO budget (category, amount) VALUES (?, ?)", (category, amount))
                
                self.conn.commit()
                
                # Refresh budget list
                load_budget_data()
                
                # Update dashboard
                self.update_dashboard()
                
                # Clear inputs
                category_var.set("")
                amount_var.set("")
                
                messagebox.showinfo("Success", f"Budget for {category} saved successfully!")
                
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid amount.")
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        def delete_budget():
            selected_items = budget_tree.selection()
            if not selected_items:
                messagebox.showinfo("Info", "Please select a category to delete its budget.")
                return
                
            category = budget_tree.item(selected_items[0], "values")[0]
            
            # Confirm deletion
            if not messagebox.askyesno("Confirm", f"Are you sure you want to remove the budget for {category}?"):
                return
                
            try:
                cursor = self.conn.cursor()
                cursor.execute("DELETE FROM budget WHERE category=?", (category,))
                self.conn.commit()
                
                # Refresh budget list
                load_budget_data()
                
                # Update dashboard
                self.update_dashboard()
                
                messagebox.showinfo("Success", f"Budget for {category} removed successfully!")
                
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")
        
        # Add buttons
        button_frame = ttk.Frame(frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        save_button = ttk.Button(button_frame, text="Save Budget", command=save_budget)
        save_button.pack(side=tk.LEFT, padx=5)
        
        delete_button = ttk.Button(button_frame, text="Remove Budget", command=delete_budget)
        delete_button.pack(side=tk.LEFT, padx=5)
        
        close_button = ttk.Button(button_frame, text="Close", command=budget_window.destroy)
        close_button.pack(side=tk.RIGHT, padx=5)
    
    def export_data(self):
        """Export expense data to CSV"""
        try:
            from tkinter import filedialog
            
            # Ask for file location
            file_path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                title="Export Expense Data"
            )
            
            if not file_path:
                return
            
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT date, amount, category, description, payment_method FROM expenses WHERE month=? AND year=? ORDER BY date",
                (self.current_month, self.current_year)
            )
            expenses = cursor.fetchall()
            
            with open(file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                # Write header
                writer.writerow(['Date', 'Amount (₹)', 'Category', 'Description', 'Payment Method'])
                # Write data
                writer.writerows(expenses)
            
            messagebox.showinfo("Export Successful", f"Expenses exported to {file_path}")
            
        except Exception as e:
            messagebox.showerror("Export Error", f"An error occurred while exporting: {str(e)}")
            
    def __del__(self):
        """Destructor to close database connection"""
        if hasattr(self, 'conn'):
            self.conn.close()


def main():
    """Main function to start the application"""
    root = tk.Tk()
    app = ExpenseTrackerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
            